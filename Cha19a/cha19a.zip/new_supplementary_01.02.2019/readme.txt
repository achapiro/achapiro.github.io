- paper_video.mp4
Supplementary video explaining our work in loose terms.

- ModelPlots folder
This folder contains three Matlab .fig files. 
Each file is a 3D plot of our model rendered for a given speed:
e.g. modelSpeed7.fig is a plot of our model for a speed of 7-second across the screen

Obs.: "N second pan" speeds were calculated for our setup, where the screen 
subtends a horizontal field-of-view of 33 degrees.
In this case, a 7 second pan is equivalent to 33/7 ~= 4.7 degrees/second, etc.
Please consider that for a different screen size or viewing distance these values may change.

- isoLinePlots folder
This folder contains iso-judder lines, as shown in the other plots.
Each line has the same judder value in our model.
These lines are useful for looking at equivalent judder between different stimuli.

- raw data folder
This folder contains the anonymized raw data from experiments 1-3 and the validation experiment.
Also contains the output of the statistical analysis of the data from R.
